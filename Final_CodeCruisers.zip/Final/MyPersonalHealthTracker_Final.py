import tkinter as tk
from tkinter import simpledialog, messagebox, ttk
from datetime import datetime
import csv
import os
import bcrypt
import matplotlib.pyplot as plt

# Function to hash a password
def hash_password(password):
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())

# Function to verify a password
def verify_password(password, hashed):
    return bcrypt.checkpw(password.encode('utf-8'), hashed)

# Function to register a new user
def register_user(username, password):
    hashed_password = hash_password(password)
    with open('users.csv', 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([username, hashed_password.decode('utf-8')])
    messagebox.showinfo("Success", "User registered successfully!")

# Function to authenticate a user
def authenticate_user(username, password):
    if not os.path.exists('users.csv'):
        messagebox.showerror("Error", "No users registered yet.")
        return False

    with open('users.csv', 'r') as file:
        reader = csv.reader(file)
        for row in reader:
            stored_username, stored_hashed_password = row
            if stored_username == username and verify_password(password, stored_hashed_password.encode('utf-8')):
                messagebox.showinfo("Success", "Authentication successful!")
                return True
        messagebox.showerror("Error", "Authentication failed!")
        return False

# Function to log daily health metrics
def log_health_metrics():
    root = tk.Tk()
    root.withdraw()

    inputs = {
        'water_intake': None,
        'steps_walked': None,
        'sleep_hours': None,
        'exercise_hours': None
    }

    dialog = tk.Toplevel(root)
    dialog.title('Log Health Metrics')
    dialog.geometry('400x300')

    tk.Label(dialog, text="Enter Daily Health Metrics", font=("Helvetica", 14)).pack(pady=10)

    frame = tk.Frame(dialog)
    frame.pack(padx=20, pady=10)

    tk.Label(frame, text="Water Intake (liters):", padx=5, pady=5).grid(row=0, column=0, sticky='w')
    tk.Label(frame, text="Steps Walked:", padx=5, pady=5).grid(row=1, column=0, sticky='w')
    tk.Label(frame, text="Sleep Hours:", padx=5, pady=5).grid(row=2, column=0, sticky='w')
    tk.Label(frame, text="Exercise Hours:", padx=5, pady=5).grid(row=3, column=0, sticky='w')

    entry_water_intake = tk.Entry(frame, width=10)
    entry_water_intake.grid(row=0, column=1, padx=5, pady=5)
    entry_steps_walked = tk.Entry(frame, width=10)
    entry_steps_walked.grid(row=1, column=1, padx=5, pady=5)
    entry_sleep_hours = tk.Entry(frame, width=10)
    entry_sleep_hours.grid(row=2, column=1, padx=5, pady=5)
    entry_exercise_hours = tk.Entry(frame, width=10)
    entry_exercise_hours.grid(row=3, column=1, padx=5, pady=5)

    def save_inputs():
        inputs['water_intake'] = entry_water_intake.get()
        inputs['steps_walked'] = entry_steps_walked.get()
        inputs['sleep_hours'] = entry_sleep_hours.get()
        inputs['exercise_hours'] = entry_exercise_hours.get()
        dialog.destroy()

    tk.Button(dialog, text="Save", command=save_inputs, width=10).pack(pady=10)
    dialog.mainloop()

    water_intake = float(inputs['water_intake'])
    steps_walked = int(inputs['steps_walked'])
    sleep_hours = float(inputs['sleep_hours'])
    exercise_hours = float(inputs['exercise_hours'])

    date = datetime.now().strftime('%Y-%m-%d')
    with open('health_log.csv', 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([date, water_intake, steps_walked, sleep_hours, exercise_hours])

    print("Health metrics logged!")

# Function to display a login or registration dialog
def login_or_register():
    root = tk.Tk()
    root.withdraw()

    authenticated = False

    # Register dialog box 
    def show_register_dialog():
        register_dialog = tk.Toplevel(root)
        register_dialog.title("Register")
        register_dialog.geometry("400x300")

        tk.Label(register_dialog, text="Username:", padx=5, pady=5).grid(row=0, column=0, sticky='w')
        tk.Label(register_dialog, text="Password:", padx=5, pady=5).grid(row=1, column=0, sticky='w')

        entry_username = tk.Entry(register_dialog, width=20)
        entry_username.grid(row=0, column=1, padx=5, pady=5)
        entry_password = tk.Entry(register_dialog, width=20, show='*')
        entry_password.grid(row=1, column=1, padx=5, pady=5)

        # Password entry field with visibility toggle
        password_var = tk.StringVar()
        entry_password = tk.Entry(register_dialog, width=20, textvariable=password_var, show='*')
        entry_password.grid(row=1, column=1, padx=5, pady=5)
        
        def toggle_password_visibility():
            if password_var.get():
                entry_password.config(show='' if show_password_var.get() else '*')
        
        show_password_var = tk.BooleanVar()
        show_password_checkbox = ttk.Checkbutton(register_dialog, text="Show Password", variable=show_password_var, command=toggle_password_visibility)
        show_password_checkbox.grid(row=2, columnspan=2, pady=10)

        def register():
            username = entry_username.get()
            password = entry_password.get()
            register_user(username, password)
            register_dialog.destroy()

        tk.Button(register_dialog, text="Register", command=register, width=10).grid(row=3, columnspan=2, pady=10)

    # Log in dialog
    def show_login_dialog():
        login_dialog = tk.Toplevel(root)
        login_dialog.title("Login")
        login_dialog.geometry("400x300")

        tk.Label(login_dialog, text="Username:", padx=5, pady=5).grid(row=0, column=0, sticky='w')
        tk.Label(login_dialog, text="Password:", padx=5, pady=5).grid(row=1, column=0, sticky='w')

        entry_username = tk.Entry(login_dialog, width=20)
        entry_username.grid(row=0, column=1, padx=5, pady=5)
        
        # Password entry field with visibility toggle
        password_var = tk.StringVar()
        entry_password = tk.Entry(login_dialog, width=20, textvariable=password_var, show='*')
        entry_password.grid(row=1, column=1, padx=5, pady=5)
        
        def toggle_password_visibility():
            if password_var.get():
                entry_password.config(show='' if show_password_var.get() else '*')
        
        show_password_var = tk.BooleanVar()
        show_password_checkbox = ttk.Checkbutton(login_dialog, text="Show Password", variable=show_password_var, command=toggle_password_visibility)
        show_password_checkbox.grid(row=2, columnspan=2, pady=10)

        def login():
            nonlocal authenticated
            username = entry_username.get()
            password = entry_password.get()
            if authenticate_user(username, password):
                authenticated = True
                login_dialog.destroy()
                root.destroy()  # Destroy the main root window after successful login
            else:
                messagebox.showerror("Error", "Login failed. Please try again.")

        tk.Button(login_dialog, text="Login", command=login, width=10).grid(row=3, columnspan=2, pady=10)

    root.deiconify()
    root.geometry("400x300")  # Increased the size of the main dialog
    tk.Label(root, text="Welcome to Health Tracker", font=("Helvetica", 16)).pack(pady=10)
    tk.Button(root, text="Register", command=show_register_dialog, width=20).pack(pady=10)
    tk.Button(root, text="Login", command=show_login_dialog, width=20).pack(pady=10)
    tk.Button(root, text="Exit", command=root.destroy, width=20).pack(pady=10)  # Added exit button
    root.mainloop()

import matplotlib.pyplot as plt
import csv
 
# Function to visualize health metrics
def visualize_health_metrics():
    dates_all, water_intakes_all, steps_walked_all, sleep_hours_all, exercise_hours_all = read_health_metrics()

    if len(dates_all) == 0:
        print("No data available to visualize.")
        return
    
    # Check if there is enough data for last 7 days
    if len(dates_all) >= 7:
        dates_7days = dates_all[-7:]
        water_intakes_7days = water_intakes_all[-7:]
        steps_walked_7days = steps_walked_all[-7:]
        sleep_hours_7days = sleep_hours_all[-7:]
        exercise_hours_7days = exercise_hours_all[-7:]
        plot_health_metrics("Last 7 Days", dates_7days, water_intakes_7days, steps_walked_7days, sleep_hours_7days, exercise_hours_7days)

    # Always plot for all available data
    plot_health_metrics("Total Days", dates_all, water_intakes_all, steps_walked_all, sleep_hours_all, exercise_hours_all)

def read_health_metrics():
    dates_all = []
    water_intakes_all = []
    steps_walked_all = []
    sleep_hours_all = []
    exercise_hours_all = []

    try:
        with open('health_log.csv', 'r') as file:
            reader = csv.reader(file)
            next(reader)  # Skip the header row
            for row in reader:
                if len(row) == 5:
                    try:
                        date = datetime.strptime(row[0], '%Y-%m-%d')
                        water_intake = float(row[1])
                        steps_walked = int(row[2])
                        sleep_hours = float(row[3])
                        exercise_hours = float(row[4])

                        dates_all.append(date)
                        water_intakes_all.append(water_intake)
                        steps_walked_all.append(steps_walked)
                        sleep_hours_all.append(sleep_hours)
                        exercise_hours_all.append(exercise_hours)
                    except ValueError:
                        print(f"Skipping invalid row: {row}")
    except FileNotFoundError:
        print("No health log file found.")
    
    return dates_all, water_intakes_all, steps_walked_all, sleep_hours_all, exercise_hours_all

def plot_health_metrics(title, dates, water_intakes, steps_walked, sleep_hours, exercise_hours):
    plt.figure(figsize=(12, 10))

    # Plotting water intake
    plt.subplot(4, 1, 1)
    plt.plot(dates, water_intakes, marker='o', linestyle='-', color='b', label='Water Intake (liters)')
    plt.title(f'{title} - Water Intake')
    plt.xlabel('Date')
    plt.ylabel('Liters')
    plt.legend()

    # Plotting steps walked
    plt.subplot(4, 1, 2)
    plt.plot(dates, steps_walked, marker='o', linestyle='-', color='g', label='Steps Walked')
    plt.title(f'{title} - Steps Walked')
    plt.xlabel('Date')
    plt.ylabel('Steps')
    plt.legend()

    # Plotting sleep hours
    plt.subplot(4, 1, 3)
    plt.plot(dates, sleep_hours, marker='o', linestyle='-', color='r', label='Sleep Hours')
    plt.title(f'{title} - Sleep Hours')
    plt.xlabel('Date')
    plt.ylabel('Hours')
    plt.legend()

    # Plotting exercise hours
    plt.subplot(4, 1, 4)
    plt.plot(dates, exercise_hours, marker='o', linestyle='-', color='purple', label='Exercise Hours')
    plt.title(f'{title} - Exercise Hours')
    plt.xlabel('Date')
    plt.ylabel('Hours')
    plt.legend()

    plt.tight_layout()
    plt.show()


# Function to calculate and check average water intake
def check_water_intake():
    try:
        dates = []
        water_intakes = []
    
        with open('health_log.csv', 'r') as file:
            reader = csv.reader(file)
            next(reader)  # Skip the header row
            for row in reader:
                # Only process valid rows
                if len(row) == 5 and row[0] and row[1]:
                    try:
                        dates.append(datetime.strptime(row[0], '%Y-%m-%d'))
                        water_intakes.append(float(row[1]))
                    except ValueError:
                        print(f"Skipping invalid row: {row}")
        
        if len(dates) >= 7:
            recent_dates = dates[-7:]
            recent_water_intakes = water_intakes[-7:]
            average_water_intake_7_days = sum(recent_water_intakes) / 7

            if average_water_intake_7_days < 2.5:
                print(f"Alert: Your average water intake over the past 7 days is {average_water_intake_7_days:.2f} liters, which is below the recommended 2.5 liters.")
                print("Suggestion: Try to drink more water. Carry a water bottle with you and set reminders to drink water throughout the day.")
            elif average_water_intake_7_days > 4.0:
                print(f"Alert: Your average water intake over the past 7 days is {average_water_intake_7_days:.2f} liters, which is above the recommended 4 liters.")
                print("Suggestion: Try to regulate your water intake. Drinking too much water can lead to overhydration. Drink water when you feel thirsty and don't force yourself to drink excessively.")
            else:
                print("Your average water intake over the past 7 days is within the recommended range.")

            total_days_logged = len(dates)
            average_water_intake_total = sum(water_intakes) / total_days_logged
            print(f"Your average water intake over the total {total_days_logged} days logged is {average_water_intake_total:.2f} liters.")
        
        else:
            total_days_logged = len(dates)
            average_water_intake_total = sum(water_intakes) / total_days_logged
            print(f"Not enough data for the last 7 days. Your average water intake over the total {total_days_logged} days logged is {average_water_intake_total:.2f} liters.")
            print("Come back after 7 days for more accurate data.")

    except FileNotFoundError:
        print("Health log file not found.")
    except csv.Error:
        print("Error reading health log file.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

 # Function to calculate and check average sleep hours       
def check_sleep_hours():
    try:
        dates = []
        sleep_hours = []
    
        with open('health_log.csv', 'r') as file:
            reader = csv.reader(file)
            next(reader)  # Skip the header row
            for row in reader:
                # Only process valid rows
                if len(row) == 5 and row[0] and row[3]:
                    try:
                        dates.append(datetime.strptime(row[0], '%Y-%m-%d'))
                        sleep_hours.append(float(row[3]))
                    except ValueError:
                        print(f"Skipping invalid row: {row}")
        
        if len(dates) >= 7:
            recent_dates = dates[-7:]
            recent_sleep_hours = sleep_hours[-7:]
            average_sleep_hours_7_days = sum(recent_sleep_hours) / 7

            if average_sleep_hours_7_days < 6:
                print(f"Alert: Your average sleep hours over the past 7 days is {average_sleep_hours_7_days:.2f} hours, which is below the recommended 6 hours.")
                print("Suggestion: Try to get more sleep. Establish a regular sleep schedule, avoid caffeine before bedtime, and create a relaxing bedtime routine.")
            elif average_sleep_hours_7_days > 10:
                print(f"Alert: Your average sleep hours over the past 7 days is {average_sleep_hours_7_days:.2f} hours, which is above the recommended 10 hours.")
                print("Suggestion: Try to regulate your sleep. Too much sleep can lead to health issues. Ensure you have a balanced routine with physical activity and a proper diet.")
            else:
                print("Your average sleep hours over the past 7 days is within the recommended range.")

            total_days_logged = len(dates)
            average_sleep_hours_total = sum(sleep_hours) / total_days_logged
            print(f"Your average sleep hours over the total {total_days_logged} days logged is {average_sleep_hours_total:.2f} hours.")
        
        else:
            total_days_logged = len(dates)
            average_sleep_hours_total = sum(sleep_hours) / total_days_logged
            print(f"Not enough data for the last 7 days. Your average sleep hours over the total {total_days_logged} days logged is {average_sleep_hours_total:.2f} hours.")
            print("Come back after 7 days for more accurate data.")

    except FileNotFoundError:
        print("Health log file not found.")
    except csv.Error:
        print("Error reading health log file.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        
# Function to calculate and check steps walked
def check_steps_walked():
    try:
        dates = []
        steps_walked = []
    
        with open('health_log.csv', 'r') as file:
            reader = csv.reader(file)
            next(reader)  # Skip the header row
            for row in reader:
                # Only process valid rows
                if len(row) == 5 and row[0] and row[2]:
                    try:
                        dates.append(datetime.strptime(row[0], '%Y-%m-%d'))
                        steps_walked.append(int(row[2]))
                    except ValueError:
                        print(f"Skipping invalid row: {row}")

        # Check for daily steps below 3000
        for date, steps in zip(dates, steps_walked):
            if steps < 3000:
                print(f"Alert: On {date.strftime('%Y-%m-%d')}, you only walked {steps} steps, which is below the recommended 3000 steps.")
                print("Suggestion: Try to walk more. Take short walks during breaks, use stairs instead of elevators, and consider walking or cycling for short distances instead of driving.")
                break
    
        if len(dates) >= 7:
            recent_dates = dates[-7:]
            recent_steps_walked = steps_walked[-7:]
            average_steps_walked_7_days = sum(recent_steps_walked) / 7
        
            if average_steps_walked_7_days < 10000:
                print(f"Alert: Your average steps walked per day over the past 7 days is {average_steps_walked_7_days:.2f}, which is below the recommended 10000 steps.")
                print("Suggestion: Try to increase your daily steps. Take short walks during breaks, use stairs instead of elevators, and consider walking or cycling for short distances instead of driving.")
            else:
                print("Your average steps walked per day over the past 7 days is within the recommended range.")
            
            total_days_logged = len(dates)
            average_steps_walked_total = sum(steps_walked) / total_days_logged
            print(f"Your average steps walked per day over the total {total_days_logged} days logged is {average_steps_walked_total:.2f}.")
        
        else:
            total_days_logged = len(dates)
            average_steps_walked_total = sum(steps_walked) / total_days_logged
            print(f"Not enough data for the last 7 days. Your average steps walked per day over the total {total_days_logged} days logged is {average_steps_walked_total:.2f}.")
            print("Come back after 7 days for more accurate data.")
    
    except FileNotFoundError:
        print("Health log file not found.")
    except csv.Error:
        print("Error reading health log file.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

# Function to calculate and check exercise hours
def check_exercise_hours():
    try:
        dates = []
        exercise_hours = []
    
        with open('health_log.csv', 'r') as file:
            reader = csv.reader(file)
            next(reader)  # Skip the header row
            for row in reader:
                # Only process valid rows
                if len(row) == 5 and row[0] and row[4]:
                    try:
                        dates.append(datetime.strptime(row[0], '%Y-%m-%d'))
                        exercise_hours.append(float(row[4]))
                    except ValueError:
                        print(f"Skipping invalid row: {row}")

        # Check for daily exercise hours outside the recommended range
        for date, exercise in zip(dates, exercise_hours):
            if exercise < 0.5:
                print(f"Alert: On {date.strftime('%Y-%m-%d')}, you only exercised for {exercise:.2f} hours, which is below the recommended 0.5 hours.")
                print("Suggestion: Try to increase your exercise time. Aim for at least 30 minutes of moderate exercise daily, such as brisk walking, cycling, or swimming.")
                break
            elif exercise > 5.0:
                print(f"Alert: On {date.strftime('%Y-%m-%d')}, you exercised for {exercise:.2f} hours, which is above the recommended 5 hours.")
                print("Suggestion: Try to regulate your exercise time. Over-exercising can lead to injury and fatigue. Balance your routine with adequate rest and recovery.")
                break
    
        if len(dates) >= 7:
            recent_dates = dates[-7:]
            recent_exercise_hours = exercise_hours[-7:]
            average_exercise_hours_7_days = sum(recent_exercise_hours) / 7
        
            if average_exercise_hours_7_days < 6:
                print(f"Alert: Your average exercise hours per day over the past 7 days is {average_exercise_hours_7_days:.2f}, which is below the recommended 6 hours.")
                print("Suggestion: Try to increase your weekly exercise time. Aim for a balanced exercise routine that includes both aerobic and strength training activities.")
            elif average_exercise_hours_7_days > 7:
                print(f"Alert: Your average exercise hours per day over the past 7 days is {average_exercise_hours_7_days:.2f}, which is above the recommended 7 hours.")
                print("Suggestion: Try to regulate your weekly exercise time. Ensure you have a balanced routine that includes adequate rest and recovery.")
            else:
                print("Your average exercise hours per day over the past 7 days is within the recommended range.")
            
            total_days_logged = len(dates)
            average_exercise_hours_total = sum(exercise_hours) / total_days_logged
            print(f"Your average exercise hours per day over the total {total_days_logged} days logged is {average_exercise_hours_total:.2f}.")
        
        else:
            total_days_logged = len(dates)
            average_exercise_hours_total = sum(exercise_hours) / total_days_logged
            print(f"Not enough data for the last 7 days. Your average exercise hours per day over the total {total_days_logged} days logged is {average_exercise_hours_total:.2f}.")
            print("Come back after 7 days for more accurate data.")
    
    except FileNotFoundError:
        print("Health log file not found.")
    except csv.Error:
        print("Error reading health log file.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

# Main program loop
def main():
    login_or_register()  # Call the login or registration dialog

    def show_main_menu():
        menu_dialog = tk.Tk()
        menu_dialog.title("Main Menu")
        menu_dialog.geometry("400x400")

        def on_menu_selection(choice):
            if choice == '1':
                log_health_metrics()
            elif choice == '2':
                visualize_health_metrics()
            elif choice == '3':
                check_water_intake()
            elif choice == '4':
                check_sleep_hours()
            elif choice == '5':
                check_steps_walked()
            elif choice == '6':
                check_exercise_hours()
            elif choice == '7':
                menu_dialog.destroy()
            else:
                messagebox.showerror("Error", "Invalid choice. Please try again.")

        tk.Label(menu_dialog, text="Select an option", font=("Helvetica", 14)).pack(pady=20)

        options = [
            ("Log Health Metrics", '1'),
            ("Visualize Health Metrics", '2'),
            ("Check Water Intake", '3'),
            ("Check Sleep Hours", '4'),
            ("Check Steps Walked", '5'),
            ("Check Exercise Hours", '6'),
            ("Exit", '7')
        ]

        for text, value in options:
            tk.Button(menu_dialog, text=text, command=lambda v=value: on_menu_selection(v), width=30).pack(pady=5)

        menu_dialog.mainloop()

    show_main_menu()

if __name__ == "__main__":
    main()

